#pragma once

// #define SDL_EVENT_QUEUE_LEN 128

#include "SDL.h"

// typedef struct {
// 	int SDL_eventQueueLen;
// 	SDL_Event** SDL_eventQueue;
// } SDL_State;

// extern SDL_State *SDL_state;
