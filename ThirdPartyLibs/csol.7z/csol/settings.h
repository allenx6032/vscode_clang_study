/* settings.h */

#ifndef SETTINGS_H
#define SETTINGS_H

void LoadSettings(int *windowWidth, int *windowHeight);
void SaveSettings(void);

#endif
