-- Yukon (Relaxed)

RELAXED = true

dofile("variants/~Yukon.lua")
