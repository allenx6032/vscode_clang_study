-- Spider (One Suit)

PACKS = 8
SUITS = 1

dofile("variants/~Spider.lua")
