-- Klondike (Deal Three)

STOCK_DEAL_CARDS = 3

dofile("variants/~Klondike.lua")