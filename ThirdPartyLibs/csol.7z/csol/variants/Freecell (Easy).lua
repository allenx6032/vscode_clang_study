-- Freecell (Easy)

EASY = true

dofile("variants/Freecell.lua")
