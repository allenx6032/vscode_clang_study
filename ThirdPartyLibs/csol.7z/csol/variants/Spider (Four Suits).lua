-- Spider (Four Suits)

PACKS = 2
SUITS = 4

dofile("variants/~Spider.lua")
