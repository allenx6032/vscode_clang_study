-- Klondike

STOCK_DEAL_CARDS = 1

dofile("variants/~Klondike.lua")