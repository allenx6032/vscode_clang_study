-- Yukon

RELAXED = false

dofile("variants/~Yukon.lua")
