-- Spider (Two Suits)

PACKS = 4
SUITS = 2

dofile("variants/~Spider.lua")
