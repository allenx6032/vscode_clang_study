-- csol.settings.lua

RED = {1,0,0,1}
GREEN = {0,1,0,1}
BLUE = {0,0,1,1}

WindowWidth = 1920
WindowHeight = 1080
BaizeColor = {red=0.1, green=0.2, blue=0.1, alpha=1}
-- Variant = "Quick Win"

io.stderr:write("csol.settings.lua processed\n")
