// graphics.h    -*- C -*-

// A BGI (Borland Graphics Library) implementation based on SDL2.
// Easy to use, pretty fast, and useful for porting old programs.
// Guido Gonzato, PhD
// August 1, 2019

#include <SDL_bgi.h>

// --- End of file graphics.h
